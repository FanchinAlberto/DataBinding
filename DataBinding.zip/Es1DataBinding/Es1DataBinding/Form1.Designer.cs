﻿
namespace Es1DataBinding
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxCognomi = new System.Windows.Forms.ComboBox();
            this.comboCognomeNome = new System.Windows.Forms.ComboBox();
            this.textModifica1 = new System.Windows.Forms.TextBox();
            this.textModifica2 = new System.Windows.Forms.TextBox();
            this.textId = new System.Windows.Forms.TextBox();
            this.textRidimensiona = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelModifica = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelNome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBoxCognomi
            // 
            this.comboBoxCognomi.FormattingEnabled = true;
            this.comboBoxCognomi.Location = new System.Drawing.Point(66, 49);
            this.comboBoxCognomi.Name = "comboBoxCognomi";
            this.comboBoxCognomi.Size = new System.Drawing.Size(121, 23);
            this.comboBoxCognomi.TabIndex = 0;
            // 
            // comboCognomeNome
            // 
            this.comboCognomeNome.FormattingEnabled = true;
            this.comboCognomeNome.Location = new System.Drawing.Point(445, 49);
            this.comboCognomeNome.Name = "comboCognomeNome";
            this.comboCognomeNome.Size = new System.Drawing.Size(121, 23);
            this.comboCognomeNome.TabIndex = 1;
            // 
            // textModifica1
            // 
            this.textModifica1.Location = new System.Drawing.Point(66, 192);
            this.textModifica1.Name = "textModifica1";
            this.textModifica1.Size = new System.Drawing.Size(100, 23);
            this.textModifica1.TabIndex = 2;
            // 
            // textModifica2
            // 
            this.textModifica2.Location = new System.Drawing.Point(66, 268);
            this.textModifica2.Name = "textModifica2";
            this.textModifica2.Size = new System.Drawing.Size(100, 23);
            this.textModifica2.TabIndex = 3;
            // 
            // textId
            // 
            this.textId.Location = new System.Drawing.Point(445, 78);
            this.textId.Name = "textId";
            this.textId.Size = new System.Drawing.Size(100, 23);
            this.textId.TabIndex = 4;
            // 
            // textRidimensiona
            // 
            this.textRidimensiona.Location = new System.Drawing.Point(445, 192);
            this.textRidimensiona.Name = "textRidimensiona";
            this.textRidimensiona.Size = new System.Drawing.Size(100, 23);
            this.textRidimensiona.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "Cognome persona";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Scrivi nella textbox1";
            // 
            // labelModifica
            // 
            this.labelModifica.AutoSize = true;
            this.labelModifica.Location = new System.Drawing.Point(66, 346);
            this.labelModifica.Name = "labelModifica";
            this.labelModifica.Size = new System.Drawing.Size(38, 15);
            this.labelModifica.TabIndex = 8;
            this.labelModifica.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(445, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "Cognome e nome persona";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(445, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(117, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Ridimensiona il form";
            // 
            // labelNome
            // 
            this.labelNome.AutoSize = true;
            this.labelNome.Location = new System.Drawing.Point(583, 52);
            this.labelNome.Name = "labelNome";
            this.labelNome.Size = new System.Drawing.Size(38, 15);
            this.labelNome.TabIndex = 11;
            this.labelNome.Text = "label3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelNome);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelModifica);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textRidimensiona);
            this.Controls.Add(this.textId);
            this.Controls.Add(this.textModifica2);
            this.Controls.Add(this.textModifica1);
            this.Controls.Add(this.comboCognomeNome);
            this.Controls.Add(this.comboBoxCognomi);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxCognomi;
        private System.Windows.Forms.ComboBox comboCognomeNome;
        private System.Windows.Forms.TextBox textModifica1;
        private System.Windows.Forms.TextBox textModifica2;
        private System.Windows.Forms.TextBox textId;
        private System.Windows.Forms.TextBox textRidimensiona;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelModifica;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelNome;
    }
}

