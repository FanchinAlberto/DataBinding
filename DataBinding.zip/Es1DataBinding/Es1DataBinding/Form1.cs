﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Es1DataBinding
{
    public partial class Form1 : Form
    {
        
        
        public Form1()
        {
        List<Persona> persone = new List<Persona>();
            string[,] names = {
            {"Jordan", "Belfort" },
            {"Paolo", "Cannone" },
            {"Mario", "Doccia" },
            {"Simone", "Panetti" }
            };
            InitializeComponent();
            GeneraLista(persone, names);
            BindCognomi(persone);

            textModifica2.DataBindings.Add("Text", textModifica1, "Text");
            labelModifica.DataBindings.Add("Text", textModifica1, "Text");
            textRidimensiona.DataBindings.Add("Text", this, "Size");
            textRidimensiona.DataBindings.Add("Size", this, "Size");

            BindingSource bindPersone = new BindingSource();
            bindPersone.DataSource = persone;

            comboCognomeNome.DataSource = bindPersone;
            comboCognomeNome.DisplayMember = "NomeCognome";

            textId.DataBindings.Add("Text", bindPersone, "Id");
            labelNome.DataBindings.Add("Text", bindPersone, "Nome");
        }

        private void GeneraLista(List<Persona> lista, string[,] data)
        {
            for(int i = 0; i < data.GetLength(0); i++)
            {
                Persona p1 = new Persona(data[i, 0], data[i, 1], i);
                lista.Add(p1);
            }
        }

        private void BindCognomi(List<Persona> lista)
        {
            BindingSource bind = new BindingSource();
            bind.DataSource = lista;
            comboBoxCognomi.DataSource = bind;
            comboBoxCognomi.DisplayMember = "Cognome";
        }

        
           

        
    }
}
