﻿namespace Es1DataBinding
{
    public class Persona
    {
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public int Id { get; set; }
        public string NomeCognome { get; set; }

        public Persona(string name, string surname, int id)
        {
            Nome = name;
            Cognome = surname;
            Id = id;
            NomeCognome = name + " " + surname;
        }
    }
}
